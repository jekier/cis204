// A simple hello world program

public class HelloWorld
{
    public static void main(String[] args)
    {
        System.out.println("Hello World!");
        System.out.println("This is a Java program.");
    }
}
