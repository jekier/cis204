# A simple hello world program

def main():
    print("Hello World!")
    print("This is a Python program.")
    
if __name__ == "__main__":
    main()
